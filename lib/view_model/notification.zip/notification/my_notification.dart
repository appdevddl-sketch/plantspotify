import 'dart:convert';
import 'dart:io';


import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:intouch/model/services/auth_service.dart';
import 'package:intouch/view/widgets/text_field_view/regex/regex.dart';

import '../../model/utils/color_resource.dart';
import 'notifiction_redirection.dart';

class MyNotification {
  FirebaseMessaging messaging=FirebaseMessaging.instance;
  static Future<void>  initialize(FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin) async {
    await requestPermissions(flutterLocalNotificationsPlugin);
    await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true, // Required to display a heads up notification
      badge: true,
      sound: true,
    );

    /// local notification
    AndroidNotificationChannel channel = const AndroidNotificationChannel(
      'Retail Royalty', // id
      'Retail Royalty', // channelName
      importance: Importance.max,
      playSound: true,
    );
    await flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.createNotificationChannel(channel);

    var androidInitialize = const AndroidInitializationSettings('ic_launcher');
    var iOSInitialize = const DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true);
    var initializationsSettings = InitializationSettings(android: androidInitialize, iOS: iOSInitialize);
    flutterLocalNotificationsPlugin.initialize(initializationsSettings,onDidReceiveBackgroundNotificationResponse:onBackgroundMessageTopLevel ,onDidReceiveNotificationResponse : (NotificationResponse ?notification) async {
      try {

        if (notification!.payload != null && notification.payload!.isNotEmpty) {
          ("payload => ${notification.payload}").logPrint();
          NotificationRedirection.notificationRedirectionFromPayload(notificationPayload: notification.payload??"");
        }
      } catch (e) {
        (e.toString()).logPrint();
      }
      return;
    });
    FirebaseMessaging.onMessage.listen((RemoteMessage message) {
      try{
        notificationDataLog(message,"onMessage");
      }catch(e){
        ("notification onMessage error=>$e").logPrint();
      }
      MyNotification.showBigTextNotification(message, flutterLocalNotificationsPlugin);
    });
    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) {
      try{
        notificationDataLog(message,"onMessageApp");
        if (message!.data != null && message.data!.isNotEmpty) {
          ("payload => ${message.data}").logPrint();
          NotificationRedirection.notificationRedirectionFromPayload(notificationPayload: jsonEncode(message.data));
        }
      }catch(e){
        ("notification onMessageApp error=>$e").logPrint();
      }
      try {
        if (message.data.isNotEmpty ) {
          (message).logPrint();
        }
      } catch (e) {
        (e.toString()).logPrint();
      }
    });
  }
  static Future<void> showBigTextNotification(RemoteMessage message, FlutterLocalNotificationsPlugin fln) async {
    if(Get.find<AuthService>().user.value.isNotification == "0" )return;
    try{
      NotificationRedirection.forLogoutNotification(notificationPayload: jsonEncode(message.data));
    }catch(e){
      ("notification error=>$e").logPrint();
    }
    try{
      String title = message.notification?.title??"";
      String body = message.notification?.body??"";
      AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
        'Retail Royalty', // id
        'Retail Royalty', // channelName
        importance: Importance.max,
        playSound: true,
        icon: 'ic_launcher',
        color:  ColorResource.instance.mainColor,
        priority: Priority.high,
        styleInformation:const BigTextStyleInformation(''),
      );
      var iOSInitialize =const DarwinNotificationDetails(
        presentAlert: true,
        presentSound: true,
      );
      NotificationDetails platformChannelSpecifics = NotificationDetails(android: androidPlatformChannelSpecifics,iOS:iOSInitialize );
      await fln.show(0, title, body, platformChannelSpecifics, payload: jsonEncode(message.data),);
    }catch(e){
      ("notification error : $e").logPrint();
    }
  }
  static Future<void>  requestPermissions(flutterLocalNotificationsPlugin) async {
    if (Platform.isIOS || Platform.isMacOS) {
      await flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
      await flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<MacOSFlutterLocalNotificationsPlugin>()?.requestPermissions(
        alert: true,
        badge: true,
        sound: true,
      );
    } else if (Platform.isAndroid) {
      final AndroidFlutterLocalNotificationsPlugin? androidImplementation = flutterLocalNotificationsPlugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
      final bool? granted = await androidImplementation?.requestNotificationsPermission();
    }
  }

  Future<String> getDeviceToken()async{
    String? token = await messaging.getToken();
    return token!;
  }
  void isTokenRefresh(){

    messaging.onTokenRefresh.listen((event){
      event.toString();
      print("token refreshed");
    });
  }
}

void onBackgroundMessageTopLevel(NotificationResponse response) {
  ("onDidReceiveBackgroundNotificationResponse: ${response.payload}").logPrint();
}

@pragma('vm:entry-point')
Future<dynamic> myBackgroundMessageHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
  try{
    notificationDataLog(message,"background");

  }catch(e){
    ("notification background error=>$e").logPrint();
  }
}


void notificationDataLog(RemoteMessage message,String notificationType){
  ("Notification type: $notificationType").logPrint();
  ("Title: ${message.notification?.title}").logPrint();
  ("Body: ${message.notification?.body}").logPrint();
  ("Data: ${message.data}").logPrint();

}


