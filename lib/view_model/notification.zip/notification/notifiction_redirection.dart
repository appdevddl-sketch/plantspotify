import 'dart:convert';

import 'package:get/get.dart';
import 'package:intouch/view/widgets/text_field_view/regex/regex.dart';


import '../../model/services/auth_service.dart';
import '../routes/app_pages.dart';

class NotificationRedirection{

  static notificationRedirectionFromPayload({required String notificationPayload}){
    try{
      Map<String,dynamic> notificationPayloadJson = jsonDecode(notificationPayload);

      // (notificationPayloadJson["link_type"]).logPrint();
      switch (notificationPayloadJson["link_type"]){
        case "doctor_appointment_detail" :{

        }
        break;
        default: {
          ("something went wrong").logPrint();
        }
        break;
      }
    }catch(e){
      (e).logPrint();
    }
  }

  static forLogoutNotification({required String notificationPayload}){
    try{
      Map<String,dynamic> notificationPayloadJson = jsonDecode(notificationPayload);
      (notificationPayloadJson).logPrint();
      switch (notificationPayloadJson["link_type"]){
        case "logout" :{
          Get.find<AuthService>().logOut();
        }
        break;
        case "force_logout" :{
          Get.find<AuthService>().logOut();
        }
        break;
        default: {
          ("something want wrong").logPrint();
        }
        break;
      }
    }catch(e){
      (e).logPrint();
    }
  }
}